// function emailSend() {
//     Email.send({
//         Host : "smtp.elasticemail.com",
//         Username : "infodctkotputli@gmail.com",
//         Password : "7C6BC84FD1B0BE987EE5F08EEF0AE2F81429",
//         To : 'infodctkotputli@gmail.com',
//         From : "nikhilbagoriya4@gmail.com",
//         Subject : "This is the subject",
//         Body : "And this is the body"
//     }).then(
//       message => alert(message)
//     );
// }